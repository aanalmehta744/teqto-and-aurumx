const express = require('express');
const router = express.Router();
const db = require('../connection'); // adjust path to your db connection file
const cron = require('node-cron');

// This cron job will run on the 1st day of every month at midnight
cron.schedule('* * 1 * *', async () => {
    const today = new Date();
    const month = today.getMonth(); // Previous month
    const year = today.getFullYear();

    // const targetMonth = 2;
    // const targetYear = 2025;

    try {
        // Get salary and unpaid leaves for last month
        const [employees] = await db.query(`
            SELECT e.id AS employee_id, e.salary,
                   IFNULL(SUM(l.no_of_days), 0) AS unpaid_days
            FROM employees e
            LEFT JOIN leave_requests l
                ON e.id = l.employee_id
                AND l.leave_type = 'Unpaid'
                AND MONTH(l.start_date) = ?
                AND YEAR(l.start_date) = ?
            GROUP BY e.id
        `, [month, year]);

        // Loop over all employees and insert salary slips
        for (const emp of employees) {
            const { employee_id, salary, unpaid_days } = emp;

            // Ensure valid salary and unpaid days
            const baseSalary = salary || 0; // Default to 0 if null or undefined
            const unpaidDays = unpaid_days || 0; // Default to 0 if null or undefined

            // Ensure unpaid days don't cause invalid calculations
            if (isNaN(baseSalary) || isNaN(unpaidDays)) {
                console.error(`Invalid data for employee ID: ${employee_id}`);
                continue; // Skip this employee if data is invalid
            }

            const perDaySalary = baseSalary / 30;  // Assuming 30 days per month
            const finalSalary = baseSalary - (unpaidDays * perDaySalary);

            // Make sure final salary is a valid number
            if (isNaN(finalSalary)) {
                console.error(`Invalid final salary for employee ID: ${employee_id}`);
                continue; // Skip this employee if final salary is invalid
            }

            // Insert salary slip into the database
            await db.query(`
                INSERT INTO salary_slips (employee_id, month, year, base_salary, unpaid_leave_days, final_salary)
                VALUES (?, ?, ?, ?, ?, ?)
            `, [employee_id, month, year, baseSalary, unpaidDays, finalSalary]);
        }

        console.log(`[${new Date().toISOString()}] Salary slips generated for ${month}/${year}`);
    } catch (err) {
        console.error('Error generating salary slips:', err);
    }
});


// 🟢 GET all employees
router.get('/', async (req, res) => {
    try {
        const sql = 'SELECT * FROM employees ';
        const [results] = await db.query(sql);
        // console.log(results);
        res.status(200).json(results);
    } catch (err) {
        console.error('Error fetching employees:', err);
        res.status(500).json({ error: 'An error occurred while fetching employees' });
    }
});

router.get('/payslip/:employeeID', async (req, res) => {
    const employeeID = req.params.employeeID;
    try {
        const sql = 'SELECT * FROM salary_slips WHERE employee_id = ? ORDER BY year DESC, month DESC';
        const [results] = await db.query(sql, [employeeID]);
        if (results.length === 0) {
            return res.status(404).json({ message: 'No payslip found for this employee.' });
        }
        res.status(200).json(results[0]);
    } catch (err) {
        console.error('Error fetching salary_slip:', err);
        res.status(500).json({ error: 'An error occurred while fetching salary slip' });
    }
});

router.get('/all-payslip/:employeeID', async (req, res) => {
    const employeeID = req.params.employeeID;
    try {
        const sql = 'SELECT * FROM salary_slips WHERE employee_id = ? ORDER BY year DESC, month DESC';
        const [results] = await db.query(sql, [employeeID]);
        if (results.length === 0) {
            return res.status(404).json({ message: 'No payslip found for this employee.' });
        }
        res.status(200).json(results);
    } catch (err) {
        console.error('Error fetching salary_slip:', err);
        res.status(500).json({ error: 'An error occurred while fetching salary slip' });
    }
});

module.exports = router;
