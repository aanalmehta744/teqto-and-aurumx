const express = require('express');
const router = express.Router();
const db = require('../connection'); // Use promise-based connection

// Get all calendar events (with optional date filter)
router.get('/', async (req, res) => {
  try {
    const { start_date, end_date } = req.query;
    let query = `SELECT * FROM calendar_event`;
    const queryParams = [];

    if (start_date && end_date) {
      query += ` WHERE start_date BETWEEN ? AND ?`;
      queryParams.push(start_date, end_date);
    }

    const [results] = await db.query(query, queryParams);
    res.json(results);
  } catch (err) {
    console.error('Error fetching calendar events:', err);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});
router.get('/:userId', async (req, res) => {
  const userId = req.params.userId;
  console.log("Employee ID", userId);

  try {
    const [rows] = await db.query(
      `SELECT * FROM calendar_event WHERE employee_id = ?`,
      [userId]
    );

    if (rows.length === 0) {
      return res.status(404).json({ message: 'No events found for this user' });
    }

    res.json(rows);
  } catch (err) {
    console.error('Server-side error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Add a new calendar event
router.post('/', async (req, res) => {
  console.log(req.body);
  try {
    const { title, employee_id, category, start_date, end_date, details } = req.body;

    console.log(req.body);
    // const start = new Date(startDate);
    // const end = new Date(endDate);

    const [result] = await db.query(
      'INSERT INTO calendar_event (title, employee_id, category, start_date, end_date, details) VALUES (?, ?, ?, ?, ?, ?)',
      [title, employee_id, category, start_date, end_date, details]
    );

    res.status(201).json({ message: 'Event added successfully' });
  } catch (err) {
    console.error('Server-side error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Update a calendar event
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { title, category, start_date, end_date, details } = req.body;
    console.log(req.body);

    // Ensure the date format is correct for MySQL (e.g., 'YYYY-MM-DD HH:MM:SS')
    const start = new Date(start_date);
    const end = new Date(end_date);

    // If the start or end date is invalid, return an error
    if (isNaN(start.getTime()) || isNaN(end.getTime())) {
      return res.status(400).json({ message: 'Invalid date format' });
    }

    // Format the dates to 'YYYY-MM-DD HH:MM:SS'
    const formattedStart = start.toISOString().slice(0, 19).replace('T', ' ');
    const formattedEnd = end.toISOString().slice(0, 19).replace('T', ' ');

    const [result] = await db.query(
      'UPDATE calendar_event SET title = ?, category = ?, start_date = ?, end_date = ?, details = ? WHERE id = ?',
      [title, category, formattedStart, formattedEnd, details, id]
    );

    if (result.affectedRows > 0) {
      res.json({ message: 'Event updated successfully!' });
    } else {
      res.status(404).json({ message: 'Event not found or no changes made.' });
    }
  } catch (err) {
    console.error('Error updating calendar event:', err);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});


// Delete a calendar event
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const [result] = await db.query('DELETE FROM calendar_event WHERE id = ?', [id]);

    res.json({ deleted: result.affectedRows, message: 'Event deleted successfully.' });
  } catch (err) {
    console.error('Error deleting calendar event:', err);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Delete multiple calendar events
router.delete('/ids', async (req, res) => {
  try {
    const { ids } = req.body;

    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ error: 'No IDs provided or invalid format' });
    }

    const [result] = await db.query('DELETE FROM calendar_event WHERE id IN (?)', [ids]);

    res.json({ deleted: result.affectedRows, message: `${result.affectedRows} events deleted successfully.` });
  } catch (err) {
    console.error('Error deleting calendar events:', err);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

module.exports = router;
