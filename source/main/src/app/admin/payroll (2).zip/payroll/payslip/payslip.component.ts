import { Component, OnInit } from '@angular/core';
import { BreadcrumbComponent } from '@shared/components/breadcrumb/breadcrumb.component';
import { ActivatedRoute } from '@angular/router';
import { EmployeeSalaryService } from '../employee-salary/employee-salary.service';
import { EmployeeSalary } from '../employee-salary/employee-salary.model';
import { PayrollService } from './payroll.service';
import { CommonModule } from '@angular/common';
import { EmployeesService } from 'app/admin/employees/allEmployees/employees.service';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

@Component({
  selector: 'app-payslip',
  templateUrl: './payslip.component.html',
  styleUrls: ['./payslip.component.scss'],
  standalone: true,
  imports: [BreadcrumbComponent, CommonModule],
})
export class PayslipComponent implements OnInit {
  employeeSalary: EmployeeSalary | null = null;
  selectedEmployee: any = null;
  payslipID: any;
  empID: any;
  constructor(
    private route: ActivatedRoute,
    private payrollService: PayrollService,
    private employeeSalaryService: EmployeeSalaryService,
    private employeeService: EmployeesService,
  ) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const empId = +params.get('id')!;
      this.empID = empId;
      // fetch employee info
      this.employeeService.getEmployeeById(empId).subscribe({
        next: (data) => {
          this.selectedEmployee = data;
          console.log("Employee Deatils ", this.selectedEmployee);

        },
        error: (err) => {
          console.error('Failed to fetch employee details:', err);
        }
      });
      this.route.queryParamMap.subscribe(queryParams => {
        const month = Number(queryParams.get('month'));
        const year = Number(queryParams.get('year'));

        if (this.empID && month && year) {
          this.loadPayslipData(this.empID, month, year);
        } else if (this.empID) {
          // fallback: load with current month/year if not passed
          const currentMonth = new Date().getMonth() + 1;
          const currentYear = new Date().getFullYear();
          this.loadPayslipData(this.empID, currentMonth, currentYear);
        }
      });
    });
  }


  loadPayslipData(employeeID: number, month: number, year: number): void {
    if (!employeeID || !month || !year) {
      console.error('Missing employee ID, month, or year.');
      return;
    }
    this.employeeSalaryService.getPayslipData(employeeID, month, year).subscribe({
      next: (data) => {
        console.log(data);
        if (!data || Object.keys(data).length === 0) {
          console.warn('No payslip data found for this period.');
          this.employeeSalary = null;
          return;
        }

        this.employeeSalary = data;

        // Use backend-calculated values
        this.selectedEmployee.finalSalary = parseFloat(data.netSalary) || 0;

        console.log('Final Salary (from backend):', this.selectedEmployee.finalSalary);
      },
      error: (error) => {
        console.error('Error fetching payslip data:', error);
      }
    });

  }

  // printPayslip() {
  //   const payslipContent = document.getElementById('payslip')?.innerHTML;

  //   if (!payslipContent) {
  //     console.error('Payslip content not found!');
  //     return;
  //   }

  //   const printWindow = window.open('', '_blank', 'width=800,height=600');

  //   if (printWindow) {
  //     printWindow.document.write(`
  //       <html>
  //         <head>
  //           <title>Payslip</title>
  //           <style>
  //             body {
  //               font-family: Arial, sans-serif;
  //               margin: 20px;
  //               padding: 0;
  //               background-color: #fff;
  //             }
  //             .payslip {
  //               width: 100%;
  //               max-width: 800px;
  //               margin: 0 auto;
  //             }
  //             .payslip-title {
  //               text-align: center;
  //               font-size: 24px;
  //               font-weight: bold;
  //             }
  //             .payment-info {
  //               margin-top: 20px;
  //               font-size: 14px;
  //             }
  //             .payment-details {
  //               margin-top: 20px;
  //             }
  //             .company-details, .employee-details {
  //               width: 48%;
  //               display: inline-block;
  //               vertical-align: top;
  //             }
  //             .company-details img {
  //               max-width: 200px;
  //               height: auto;
  //             }
  //             .employee-details {
  //               text-align: right;
  //             }
  //             .line-items {
  //               margin-top: 20px;
  //             }
  //             .table {
  //               width: 100%;
  //               border-collapse: collapse;
  //               margin-top: 10px;
  //             }
  //             .table td {
  //               border: 1px solid #000 !important;
  //               padding: 8px;
  //             }
  //             .right-align {
  //                text-align: right;
  //               padding-right: 100px;
  //             }
  //             .print_btn, .p-date {
  //               display: none;
  //             }
  //             @media print {
  //               body {
  //                 margin: 0;
  //               }
  //               .payslip {
  //                 width: 100%;
  //                 max-width: 100%;
  //                 margin: 0;
  //               }
  //               .company-details, .employee-details {
  //                 width: 48%;
  //                 display: inline-block;
  //                 vertical-align: top;
  //               }
  //               img {
  //                 max-width: 200px;
  //                 height: auto;
  //               }
  //               .payslip-title {
  //                 font-size: 28px;
  //               }
  //               .table td {
  //                 padding: 12px;
  //               }
  //               .print-btn,.p-date {
  //                 display: none;
  //               }
  //             }
  //           </style>
  //         </head>
  //         <body>
  //           <div class="payslip">

  //             ${payslipContent}
  //           </div>
  //         </body>
  //       </html>
  //     `);
  //     printWindow.document.close();
  //     printWindow.focus();
  //     printWindow.print();
  //     printWindow.close();
  //   }
  // }
  printPayslip() {
    const element = document.getElementById('payslip');
    const button = document.querySelector('.print_btn'); // or give the button a specific id if needed

    if (!element) {
      console.error('Payslip container not found!');
      return;
    }

    // Hide the button before generating PDF
    if (button) {
      button.classList.add('hidden-in-pdf');
    }

    html2canvas(element, { scale: 2 }).then(canvas => {
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`Payslip-${this.selectedEmployee?.fullName || 'employee'}.pdf`);
    }).catch(err => {
      console.error('Error generating PDF:', err);
    }).finally(() => {
      // Show the button again after generating PDF
      if (button) {
        button.classList.remove('hidden-in-pdf');
      }
    });
  }

}