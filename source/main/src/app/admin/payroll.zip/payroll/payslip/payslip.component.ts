import { Component, OnInit } from '@angular/core';
import { BreadcrumbComponent } from '@shared/components/breadcrumb/breadcrumb.component';
import { ActivatedRoute } from '@angular/router';
import { EmployeeSalaryService } from '../employee-salary/employee-salary.service';
import { EmployeeSalary } from '../employee-salary/employee-salary.model';
import { PayrollService } from './payroll.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-payslip',
  templateUrl: './payslip.component.html',
  styleUrls: ['./payslip.component.scss'],
  standalone: true,
  imports: [BreadcrumbComponent, CommonModule],
})
export class PayslipComponent implements OnInit {
  employeeSalary: EmployeeSalary | null = null;
  selectedEmployee: any = null;
  payslipID: any;
  empID: any;
  constructor(
    private route: ActivatedRoute,
    private payrollService: PayrollService,
    private employeeSalaryService: EmployeeSalaryService,
  ) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const empId = +params.get('id')!;
      this.empID = empId;

      if (this.empID) {
        this.loadPayslipData(this.empID);
      }
    });
    // store the selected employee info separately
    // this.selectedEmployee = this.payrollService.getSelectedRow();
    // console.log("Selected Employee details ", this.selectedEmployee);

    this.empID = this.selectedEmployee?.id;
    console.log("Employee id", this.empID);

    if (this.empID) {
      this.loadPayslipData(this.empID);
    }
  }

  loadPayslipData(employeeID: number): void {
    if (!employeeID) {
      console.error('Employee ID is missing.');
      return;
    }

    this.employeeSalaryService.getPayslipData(employeeID).subscribe({
      next: (data) => {
        this.employeeSalary = data;
        console.log('Fetched payslip data:', data);
      },
      error: (error) => {
        console.error('Error fetching payslip data:', error);
      }
    });
  }
  printPayslip() {
    const payslipContent = document.getElementById('payslip')?.innerHTML;

    if (!payslipContent) {
      console.error('Payslip content not found!');
      return;
    }

    const printWindow = window.open('', '_blank', 'width=800,height=600');

    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Payslip</title>
            <style>
              body {
                font-family: Arial, sans-serif;
                margin: 20px;
                padding: 0;
                background-color: #fff;
              }
              .payslip {
                width: 100%;
                max-width: 800px;
                margin: 0 auto;
              }
              .payslip-title {
                text-align: center;
                font-size: 24px;
                font-weight: bold;
              }
              .payment-info {
                margin-top: 20px;
                font-size: 14px;
              }
              .payment-details {
                margin-top: 20px;
              }
              .company-details, .employee-details {
                width: 48%;
                display: inline-block;
                vertical-align: top;
              }
              .company-details img {
                max-width: 200px;
                height: auto;
              }
              .employee-details {
                text-align: right;
              }
              .line-items {
                margin-top: 20px;
              }
              .table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 10px;
              }
              .table td {
                border: 1px solid #000 !important;
                padding: 8px;
              }
              .right-align {
                 text-align: right;
                padding-right: 100px;
              }
              .print_btn, .p-date {
                display: none;
              }
              @media print {
                body {
                  margin: 0;
                }
                .payslip {
                  width: 100%;
                  max-width: 100%;
                  margin: 0;
                }
                .company-details, .employee-details {
                  width: 48%;
                  display: inline-block;
                  vertical-align: top;
                }
                img {
                  max-width: 200px;
                  height: auto;
                }
                .payslip-title {
                  font-size: 28px;
                }
                .table td {
                  padding: 12px;
                }
                .print-btn,.p-date {
                  display: none;
                }
              }
            </style>
          </head>
          <body>
            <div class="payslip">
              
              ${payslipContent}
            </div>
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.focus();
      printWindow.print();
      printWindow.close();
    }
  }





}