export class EmployeeSalary {
  id: number;
  img: string;
  name: string;
  fullName: string;
  email: string;
  payslip: string;
  role: string;
  empID: string;
  department: string;
  salary: number;
  final_salary : number;
  base_salary : number;
  unpaid_leave_days : number;
  year : number;
  month : number;
  generated_at: string;
  constructor(employeeSalary: EmployeeSalary) {
    {
      this.id = employeeSalary.id || this.getRandomID();
      this.img = employeeSalary.img || 'assets/images/user/user1.jpg';
      this.name = employeeSalary.name || '';
      this.fullName = employeeSalary.fullName || '';
      this.email = employeeSalary.email || '';
      this.payslip = employeeSalary.payslip || '';
      this.role = employeeSalary.role || '';
      this.empID = employeeSalary.empID || '';
      this.department = employeeSalary.department || '';
      this.salary = Number(employeeSalary.salary) || 0;
      this.final_salary = Number(employeeSalary.final_salary) || 0;
      this.base_salary = Number(employeeSalary.base_salary) || 0;
      this.unpaid_leave_days = employeeSalary.unpaid_leave_days|| 0;
      this.year = employeeSalary.year|| 0;
      this.month = employeeSalary.month|| 0;
      this.generated_at = employeeSalary.generated_at || ''; 
    }
  }
  public getRandomID(): number {
    const S4 = () => {
      return ((1 + Math.random()) * 0x10000) | 0;
    };
    return S4() + S4();
  }
}
