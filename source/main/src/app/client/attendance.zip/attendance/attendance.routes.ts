import { Route } from "@angular/router";
import { AttendancesComponent } from "./attendance.component";
import { EmployeeAttendanceComponent } from "./employee-attendance/employee-attendance.component";
import { TodayComponent } from "./today/today.component";

export const EMPLOYEEATTENDANCE_ROUTE: Route[] = [
    {
        path: "",
        component: AttendancesComponent,
    },
    {
        path: "employee-attendance",
        component: EmployeeAttendanceComponent,
    },
    {
        path: "today-attendance",
        component: TodayComponent,
    },
]