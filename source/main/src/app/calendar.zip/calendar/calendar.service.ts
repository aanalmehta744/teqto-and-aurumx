import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, map } from 'rxjs/operators';
import { Calendar } from './calendar.model';
import { environment } from 'environments/environment';
@Injectable({
  providedIn: 'root',
})
export class CalendarService {
  private API_URL = `${environment.apiUrl}/calendar`;

  dataChange: BehaviorSubject<Calendar[]> = new BehaviorSubject<Calendar[]>([]);
  dialogData!: Calendar;

  constructor(private httpClient: HttpClient) { }

  get data(): Calendar[] {
    return this.dataChange.value;
  }

  getDialogData(): Calendar {
    return this.dialogData;
  }

  getAllCalendars(): Observable<any[]> {
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    const currentUserId = currentUser.id;

    if (!currentUserId) {
      return throwError(() => new Error('No logged-in user found.'));
    }

    return this.httpClient
      .get<Calendar[]>(`${this.API_URL}/${currentUserId}`)
      .pipe(
        map(events =>
          events.map(ev => ({
            id: ev.id,
            title: ev.title,
            category: ev.category,
            start: ev.start_date.replace('Z', ''), // Remove Z to prevent UTC shift
            end: ev.end_date ? ev.end_date.replace('Z', '') : undefined,
            color: ev.category === 'work' ? '#1976d2' :
              ev.category === 'personal' ? '#43a047' :
                ev.category === 'important' ? '#e53935' : '#9e9e9e'
          }))
        ),
        catchError(this.errorHandler)
      );
  }

  addCalendar(calendar: Calendar): Observable<Calendar> {
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    const currentUserId = currentUser.id;

    if (!currentUserId) {
      return throwError(() => new Error('No logged-in user found.'));
    }

    const calendarWithUser = {
      ...calendar,
      employee_id: currentUserId,
    };

    return this.httpClient
      .post<Calendar>(this.API_URL, calendarWithUser)
      .pipe(catchError(this.errorHandler));
  }

  updateCalendar(calendar: Calendar): Observable<Calendar> {
    return this.httpClient
      .put<Calendar>(`${this.API_URL}/${calendar.id}`, calendar)
      .pipe(catchError(this.errorHandler));
  }

  deleteCalendar(id: number): Observable<any> {
    return this.httpClient
      .delete(`${this.API_URL}/${id}`)
      .pipe(catchError(this.errorHandler));
  }
  private errorHandler(error: HttpErrorResponse): Observable<never> {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Client-side error: ${error.error.message}`;
    } else {
      errorMessage = `Server-side error: ${error.status}\nMessage: ${error.message}`;
    }
    console.error(errorMessage);
    return throwError(() => new Error(errorMessage));
  }
}
