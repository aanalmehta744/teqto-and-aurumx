import { Component, ViewChild, OnInit } from '@angular/core';
import {
  CalendarOptions,
  DateSelectArg,
  EventClickArg,
  EventApi,
} from '@fullcalendar/core';
import { EventInput } from '@fullcalendar/core';
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction';
import timeGridPlugin from '@fullcalendar/timegrid';
import listPlugin from '@fullcalendar/list';

import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import {
  UntypedFormBuilder,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { Calendar } from './calendar.model';
import { FormDialogComponent } from './dialogs/form-dialog/form-dialog.component';
import { CalendarService } from './calendar.service';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';
import { INITIAL_EVENTS } from './events-util';
import {
  MatCheckboxChange,
  MatCheckboxModule,
} from '@angular/material/checkbox';
import { UnsubscribeOnDestroyAdapter } from '@shared/UnsubscribeOnDestroyAdapter';
import { FullCalendarModule } from '@fullcalendar/angular';
import { MatButtonModule } from '@angular/material/button';
import { BreadcrumbComponent } from '@shared/components/breadcrumb/breadcrumb.component';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from '@danielmoncada/angular-datetime-picker';
import { FullCalendarComponent } from '@fullcalendar/angular';
import { HolidayService } from 'app/admin/holidays/all-holidays/all-holidays.service';
import { formatDate } from '@angular/common';

@Component({
  selector: 'app-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.scss'],
  standalone: true,
  imports: [
    BreadcrumbComponent,
    MatButtonModule,
    MatCheckboxModule,
    FullCalendarModule,
    OwlDateTimeModule,
    OwlNativeDateTimeModule,
    MatDialogModule
  ],
})
export class CalendarComponent extends UnsubscribeOnDestroyAdapter implements OnInit {
  @ViewChild('calendar', { static: false }) calendarComponent!: FullCalendarComponent;

  public addCusForm: UntypedFormGroup;
  dialogTitle: string;
  filterItems: string[] = ['work', 'personal', 'important', 'travel', 'friends'];
  calendarData!: Calendar;
  calendarEvents: EventInput[] = [];
  holidayEvents: EventInput[] = [];

  public filters: Array<{ name: string; value: string; checked: boolean }> = [
    { name: 'work', value: 'Work', checked: true },
    { name: 'personal', value: 'Personal', checked: true },
    { name: 'important', value: 'Important', checked: true },
    { name: 'travel', value: 'Travel', checked: true },
    { name: 'friends', value: 'Friends', checked: true },
  ];

  calendarOptions: CalendarOptions = {
    plugins: [dayGridPlugin, timeGridPlugin, listPlugin, interactionPlugin],
    headerToolbar: {
      left: 'prev,next today',
      center: 'title',
      right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek',
    },
    initialView: 'dayGridMonth',
    timeZone: 'local',
    editable: true,
    selectable: true,
    selectMirror: true,
    dayMaxEvents: true,
    select: this.handleDateSelect.bind(this),
    eventClick: this.handleEventClick.bind(this),
    eventsSet: this.handleEvents.bind(this),
    events: [],
    eventDidMount: (info) => {
      if (info.event.groupId === 'holiday') {
        // Native browser tooltip
        info.el.setAttribute('title', `Holiday: ${info.event.title}`);
      }
    }
  };
  constructor(
    private fb: UntypedFormBuilder,
    private dialog: MatDialog,
    public calendarService: CalendarService,
    private snackBar: MatSnackBar,
    private holidayService: HolidayService,
  ) {
    super();
    this.dialogTitle = 'Add New Event';
    this.addCusForm = this.createCalendarForm({} as Calendar);
  }

  ngOnInit(): void {
    this.loadData();
    this.loadHolidays();
  }

  handleDateSelect(selectInfo: DateSelectArg) {
    this.addNewEvent();
  }
  loadData() {
    this.calendarService.getAllCalendars().subscribe((events) => {
      console.log("Calendar event list", events);
      this.calendarEvents = events.map((event) => ({
        id: event.id,
        title: event.title,
        start: new Date(event.start.replace(' ', 'T')), // good
        end: new Date(event.end.replace(' ', 'T')),
        className: this.getClassNameValue(event.category),
        groupId: event.category,
        extendedProps: { details: event.details },
      }));
      this.mergeEvents();
    });
  }

  loadHolidays(): void {
    this.holidayService.getAllHolidays().subscribe({
      next: (res) => {
        this.holidayEvents = res
          .filter((holiday: any) => !!holiday?.date)
          .map((holiday: any) => ({
            id: holiday.id,
            title: holiday.hName,
            start: formatDate(holiday.date, 'yyyy-MM-dd', 'en-US'),
            display: 'auto',
            className: 'holiday-event',
            groupId: 'holiday'
          }));
        this.mergeEvents();
      },
      error: (err) => console.error('Error loading holidays:', err)
    });
  }
  mergeEvents() {
    this.calendarOptions = {
      ...this.calendarOptions,
      events: [
        ...this.calendarEvents,
        ...this.holidayEvents
      ]
    };
  }
  handleEventClick(clickInfo: EventClickArg) {
    this.eventClick(clickInfo);
  }

  eventClick(row: EventClickArg) {
    const calendarData = {
      id: row.event.id,
      title: row.event.title,
      category: row.event.groupId,
      start_date: row.event.start,
      end_date: row.event.end,
      details: row.event.extendedProps['details'],
    };

    const dialogRef = this.dialog.open(FormDialogComponent, {
      data: { calendar: calendarData, action: 'edit' },
      direction: localStorage.getItem('isRtl') === 'true' ? 'rtl' : 'ltr',
    });
    console.log(calendarData);
    this.subs.sink = dialogRef.afterClosed().subscribe((result) => {
      this.calendarData = this.calendarService.getDialogData();

      if (result === 'updated') {
        this.loadData();
        this.showNotification('black', 'Edit Record Successfully...!!!', 'bottom', 'center');
        this.addCusForm.reset();
      } else if (result === 'added') {
        this.loadData();
        this.showNotification('snackbar-success', 'New Record Added Successfully...!!!', 'bottom', 'center');
      } else if (result === 'delete') {
        this.loadData();
        this.showNotification('snackbar-danger', 'Delete Record Successfully...!!!', 'bottom', 'center');
      }
    });
  }

  addNewEvent() {
    const dialogRef = this.dialog.open(FormDialogComponent, {
      data: { calendar: {} as Calendar, action: 'add' },
      direction: localStorage.getItem('isRtl') === 'true' ? 'rtl' : 'ltr',
    });

    this.subs.sink = dialogRef.afterClosed().subscribe((result) => {
      if (result === 'added') {
        this.calendarData = this.calendarService.getDialogData();
        this.loadData();
        this.addCusForm.reset();
        this.showNotification('snackbar-success', 'Add Record Successfully...!!!', 'bottom', 'center');
      }
    });
  }

  changeCategory(event: MatCheckboxChange, filter: { name: string }) {
    if (event.checked) {
      this.filterItems.push(filter.name);
    } else {
      this.filterItems = this.filterItems.filter((item) => item !== filter.name);
    }
    this.filterEvent(this.filterItems);
  }

  filterEvent(categories: string[]) {
    const filteredEvents = this.calendarEvents.filter((event) =>
      categories.includes(event.groupId as string)
    );
    if (this.calendarComponent?.getApi()) {
      this.calendarComponent.getApi().removeAllEvents();
      filteredEvents.forEach(event => this.calendarComponent.getApi().addEvent(event));
    }
  }

  handleEvents(events: EventApi[]) {
    // Optional: react to calendar internal state updates
  }
  createCalendarForm(calendar: Calendar): UntypedFormGroup {
    return this.fb.group({
      id: [calendar.id],
      title: [calendar.title, [Validators.required]],
      category: [calendar.category],
      start_date: [calendar.start_date, [Validators.required]],
      end_date: [calendar.end_date, [Validators.required]],
      details: [calendar.details, [Validators.required]],
    });
  }

  showNotification(
    colorName: string,
    text: string,
    placementFrom: MatSnackBarVerticalPosition,
    placementAlign: MatSnackBarHorizontalPosition
  ) {
    this.snackBar.open(text, '', {
      duration: 2000,
      verticalPosition: placementFrom,
      horizontalPosition: placementAlign,
      panelClass: colorName,
    });
  }

  getClassNameValue(category: string) {
    switch (category) {
      case 'work': return 'fc-event-success';
      case 'personal': return 'fc-event-warning';
      case 'important': return 'fc-event-primary';
      case 'travel': return 'fc-event-danger';
      case 'friends': return 'fc-event-info';
      default: return '';
    }
  }
}
