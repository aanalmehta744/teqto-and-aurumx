import { MAT_DIALOG_DATA, MatDialogRef, MatDialogContent } from '@angular/material/dialog';
import { Component, Inject } from '@angular/core';
import { CalendarService } from '../../calendar.service';
import { UntypedFormControl, Validators, UntypedFormGroup, UntypedFormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Calendar } from '../../calendar.model';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from '@danielmoncada/angular-datetime-picker';
import { MatOptionModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { formatDate } from '@angular/common';
export interface DialogData {
  id: number;
  action: string;
  calendar: Calendar;
  employee_id: number;
}

@Component({
  selector: 'app-form-dialog:not(l)',
  templateUrl: './form-dialog.component.html',
  styleUrls: ['./form-dialog.component.scss'],
  standalone: true,
  imports: [
    MatButtonModule,
    MatIconModule,
    MatDialogContent,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatOptionModule,
    OwlDateTimeModule,
    OwlNativeDateTimeModule,
  ],
})
export class FormDialogComponent {
  action: string;
  dialogTitle: string;
  calendarForm: UntypedFormGroup;
  calendar: Calendar;
  showDeleteBtn = false;
  constructor(
    public dialogRef: MatDialogRef<FormDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    public calendarService: CalendarService,
    private fb: UntypedFormBuilder
  ) {
    // Set the defaults

    this.action = data.action;
    if (this.action === 'edit') {
      this.dialogTitle = data.calendar.title;
      this.calendar = {
        ...data.calendar,
        start_date: data.calendar.start_date,
        end_date: data.calendar.end_date,
      };
      this.showDeleteBtn = true;
    } else {
      this.dialogTitle = 'New Event';
      const blankObject = {} as Calendar;
      this.calendar = new Calendar(blankObject);
      this.showDeleteBtn = false;
    }
    console.log(this.calendar);
    this.calendarForm = this.createContactForm();
  }
  formControl = new UntypedFormControl('', [
    Validators.required,
    // Validators.email,
  ]);
  getErrorMessage() {
    return this.formControl.hasError('required')
      ? 'Required field'
      : this.formControl.hasError('email')
        ? 'Not a valid email'
        : '';
  }
  createContactForm(): UntypedFormGroup {
    return this.fb.group({
      id: [this.calendar.id],
      title: [this.calendar.title, [Validators.required]],
      category: [this.calendar.category],
      start_date: [this.calendar.start_date, [Validators.required]],
      end_date: [this.calendar.end_date, [Validators.required]],
      details: [this.calendar.details],
    });
  }
  submit() {
    // emppty stuff
  }
  deleteEvent() {
    const calendarId = this.calendarForm.getRawValue().id;

    if (calendarId) {
      this.calendarService.deleteCalendar(calendarId).subscribe({
        next: () => {
          this.dialogRef.close('delete');
        },
        error: (err) => {
          console.error('Failed to delete event:', err);
        }
      });
    } else {
      console.error('No calendar ID found for deletion.');
    }
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  public confirmAdd(): void {
    const formData = this.calendarForm.getRawValue();

    // Convert Date objects to local YYYY-MM-DD HH:mm:ss strings
    const toLocalDateTimeString = (date: any) => {
      if (!date) return date;
      if (date instanceof Date && !isNaN(date.getTime())) {
        // Force local YYYY-MM-DD HH:mm:ss (not UTC)
        const year = date.getFullYear();
        const month = ('0' + (date.getMonth() + 1)).slice(-2);
        const day = ('0' + date.getDate()).slice(-2);
        const hours = ('0' + date.getHours()).slice(-2);
        const minutes = ('0' + date.getMinutes()).slice(-2);
        const seconds = ('0' + date.getSeconds()).slice(-2);
        return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
      }
      return date;
    };


    formData.start_date = toLocalDateTimeString(formData.start_date);
    formData.end_date = toLocalDateTimeString(formData.end_date);

    console.log('Submit record', formData);

    if (this.action === 'edit') {
      this.calendarService.updateCalendar(formData).subscribe(() => {
        this.dialogRef.close('updated');
      });
    }
    else {
      this.calendarService.addCalendar(formData).subscribe(() => {
        this.dialogRef.close('added');
      });
    }
  }
}
