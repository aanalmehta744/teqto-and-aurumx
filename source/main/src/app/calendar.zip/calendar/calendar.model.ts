import { formatDate } from '@angular/common';
export class Calendar {
  id: string;
  title: string;
  category: string;
  start_date: string;
  end_date: string;
  details: string;

  constructor(calendar: Calendar) {
    {
      this.id = calendar.id || '';
      this.title = calendar.title || '';
      this.category = calendar.category || '';
      this.start_date = formatDate(new Date(), 'yyyy-MM-dd HH:mm:ss', 'en') || '';
      this.end_date = formatDate(new Date(), 'yyyy-MM-dd HH:mm:ss', 'en') || '';

      this.details = calendar.details || '';
    }
  }

}
